<!-- header -->
<?php include 'template/header.php' ?>
<!-- navbar -->
<?php include 'template/navbar.php' ?>
<!-- Begin Page Content -->
<div class="container-fluid">

   <div class="jumbotron">
      <h1 class="display-4">SPK Pemilihan VGA Dengan Metode TOPSIS</h1>
      <p class="lead">Sistem Pendukung Keputusan Pemilihan VGA Dengan Menggunakan Metode TOPSIS</p>
   </div>
</div>
<!-- /.container-fluid -->
<!-- footer -->
<?php include 'template/footer.php' ?>